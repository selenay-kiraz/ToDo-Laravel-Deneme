<?php

// Home Page
Route::get('/', 'AuthController@home');

//Login ve Logout olma işlemleri:
Route::get('/login', ['middleware' => 'guest', 'uses' => 'AuthController@getLogin']);
Route::post('/login', ['middleware' => 'guest', 'uses' => 'AuthController@postLogin']);
Route::get('/logout', ['middleware' => 'auth', 'uses' => 'AuthController@logout']);

// Kullanıcı Profilleri
Route::resource('user', 'UserController', ['except' => ['index', 'show', 'destroy']]);

// Todo Resources
Route::resource('todo', 'TodoController', ['middleware' => 'auth']);
