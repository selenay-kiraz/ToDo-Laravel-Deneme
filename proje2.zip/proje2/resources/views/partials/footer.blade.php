<hr/>

<div class="container">
    &copy; {{ date('Y') }}, <a href="http://milon.im">Nuruzzaman Milon</a>
    <br/>
</div>